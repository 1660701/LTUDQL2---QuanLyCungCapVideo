﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CungCapVideo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection connect = new SqlConnection(@"Data Source = ANHTUAN; Initial Catalog = CungCapVideo; User ID = sa; Password = 123;");
            try
            {
                if (connect.State == ConnectionState.Closed)
                    connect.Open();
                string query = "select count(1) from dbo.Login where User=@UserName and Password=@Password";
                SqlCommand command = new SqlCommand(query, connect);
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@UserName", txtDangNhap.Text);
                command.Parameters.AddWithValue("@Password", txtMatKhau.Password);
                int count = Convert.ToInt32(command.ExecuteScalar());
                if (count ==1)
                {
                    MainWindow dashboard = new MainWindow();
                    dashboard.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Tài khoản và mật khẩu không chính xác!");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connect.Close();
            }
        }
    }
}
